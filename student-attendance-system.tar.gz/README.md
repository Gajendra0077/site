# Student Attendance System

A modern, responsive web application for managing student attendance with WhatsApp notifications.

## Features

- **Dashboard**: Real-time attendance statistics and today's records
- **Student Management**: Add, edit, and delete student records
- **Attendance Tracking**: Bulk attendance marking with status options (Present, Absent, Late, Excused)
- **WhatsApp Notifications**: Automatic alerts to parents for absent/late students
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Search & Filter**: Find students and attendance records quickly

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Shadcn/ui
- **Backend**: Node.js, Express, TypeScript
- **Notifications**: Twilio WhatsApp API
- **Storage**: In-memory (easily upgradeable to PostgreSQL/MongoDB)
- **Build Tool**: Vite
- **State Management**: TanStack Query

## Quick Start

### Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Open http://localhost:5000

### Production Deployment

See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for complete deployment instructions.

## Environment Variables

Copy `.env.example` to `.env` and configure:

```env
NODE_ENV=production
PORT=3000
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_whatsapp_number
```

## WhatsApp Integration

The system automatically sends WhatsApp notifications to parents when students are marked as absent or late. Configure Twilio credentials in your environment to enable this feature.

## API Endpoints

- `GET /api/students` - Get all students
- `POST /api/students` - Create new student
- `GET /api/attendance/today` - Get today's attendance
- `POST /api/attendance/bulk` - Bulk attendance marking
- `GET /api/classes` - Get all classes

## License

MIT License