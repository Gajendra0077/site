import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  studentId: varchar("student_id", { length: 50 }).notNull().unique(),
  email: text("email"),
  parentPhone: text("parent_phone"),
  grade: text("grade"),
  active: boolean("active").default(true).notNull(),
});

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  description: text("description"),
  schedule: text("schedule"), // JSON string for schedule info
  active: boolean("active").default(true).notNull(),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  classId: integer("class_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
  status: text("status").notNull(), // 'present', 'absent', 'late', 'excused'
  time: text("time"), // HH:MM format
  notes: text("notes"),
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export const insertClassSchema = createInsertSchema(classes).omit({
  id: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
});

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertClass = z.infer<typeof insertClassSchema>;
export type Class = typeof classes.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

// Extended types for API responses
export type AttendanceWithStudent = Attendance & {
  student: Student;
  class: Class;
};

export type StudentWithAttendance = Student & {
  todayAttendance?: Attendance;
};
