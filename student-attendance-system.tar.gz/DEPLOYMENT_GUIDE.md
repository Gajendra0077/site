# Student Attendance System - Deployment Guide

This guide will help you deploy the Student Attendance System on your own server.

## Prerequisites

- Node.js 18+ and npm
- A domain name (optional but recommended)
- SSL certificate (for production)
- Twilio account for WhatsApp notifications (optional)

## Files Structure

```
student-attendance-system/
├── client/              # React frontend
├── server/              # Express backend
├── shared/              # Shared types and schemas
├── package.json         # Dependencies
├── vite.config.ts       # Vite configuration
├── tailwind.config.ts   # Tailwind CSS config
└── tsconfig.json        # TypeScript config
```

## Deployment Steps

### 1. Server Setup

1. **Clone/Upload the code** to your server
2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Build the frontend**:
   ```bash
   npm run build
   ```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
# Server Configuration
NODE_ENV=production
PORT=3000

# WhatsApp Notifications (Optional - via Twilio)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=your_twilio_whatsapp_number

# Additional security (recommended for production)
SESSION_SECRET=your_random_session_secret_here
```

### 3. Production Deployment Options

#### Option A: Using PM2 (Recommended)

1. **Install PM2 globally**:
   ```bash
   npm install -g pm2
   ```

2. **Create ecosystem file** (`ecosystem.config.js`):
   ```javascript
   module.exports = {
     apps: [{
       name: 'attendance-system',
       script: 'server/index.ts',
       interpreter: 'node',
       interpreter_args: '--loader tsx',
       env: {
         NODE_ENV: 'production',
         PORT: 3000
       },
       instances: 1,
       autorestart: true,
       watch: false,
       max_memory_restart: '1G'
     }]
   };
   ```

3. **Start with PM2**:
   ```bash
   pm2 start ecosystem.config.js
   pm2 startup
   pm2 save
   ```

#### Option B: Using Docker

1. **Create Dockerfile**:
   ```dockerfile
   FROM node:18-alpine

   WORKDIR /app
   COPY package*.json ./
   RUN npm install

   COPY . .
   RUN npm run build

   EXPOSE 3000
   CMD ["npm", "start"]
   ```

2. **Create docker-compose.yml**:
   ```yaml
   version: '3.8'
   services:
     attendance-system:
       build: .
       ports:
         - "3000:3000"
       environment:
         - NODE_ENV=production
       restart: unless-stopped
   ```

3. **Deploy**:
   ```bash
   docker-compose up -d
   ```

#### Option C: Direct Node.js

1. **Add production start script** to `package.json`:
   ```json
   {
     "scripts": {
       "start": "NODE_ENV=production tsx server/index.ts",
       "build": "vite build"
     }
   }
   ```

2. **Start the application**:
   ```bash
   npm run build
   npm start
   ```

### 4. Nginx Configuration (Recommended)

Create `/etc/nginx/sites-available/attendance-system`:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    # SSL Configuration
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/attendance-system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5. SSL Certificate (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 6. Firewall Configuration

```bash
sudo ufw allow 22     # SSH
sudo ufw allow 80     # HTTP
sudo ufw allow 443    # HTTPS
sudo ufw enable
```

## WhatsApp Notifications Setup

### 1. Twilio Account Setup

1. Sign up at [twilio.com](https://twilio.com)
2. Get your Account SID and Auth Token from the console
3. Set up WhatsApp Business API or use Twilio Sandbox

### 2. WhatsApp Sandbox (For Testing)

1. Go to Twilio Console > Messaging > Try it out > Send a WhatsApp message
2. Follow the instructions to join the sandbox
3. Use the sandbox number as your `TWILIO_PHONE_NUMBER`

### 3. Production WhatsApp Setup

For production, you'll need:
1. A verified WhatsApp Business account
2. Twilio WhatsApp Business API approval
3. A dedicated WhatsApp Business phone number

## Database Migration (Future)

The current system uses in-memory storage. For production, consider:

1. **PostgreSQL Integration**:
   - Install PostgreSQL
   - Update connection string in environment
   - Run database migrations

2. **MongoDB Integration**:
   - Install MongoDB
   - Update storage layer to use MongoDB
   - Set up proper indexing

## Monitoring and Maintenance

### Health Checks

Add to your server monitoring:
- Check if the process is running
- Monitor memory usage
- Check response times
- Monitor disk space

### Log Management

```bash
# View PM2 logs
pm2 logs attendance-system

# Set up log rotation
pm2 install pm2-logrotate
```

### Backup Strategy

1. **Code Backup**: Regular git pushes
2. **Data Backup**: If using database, set up automated backups
3. **Configuration Backup**: Keep environment variables secure

## Security Considerations

1. **Environment Variables**: Never commit `.env` files
2. **HTTPS**: Always use SSL in production
3. **Updates**: Keep dependencies updated
4. **Access Control**: Implement proper user authentication
5. **Rate Limiting**: Add rate limiting to prevent abuse

## Troubleshooting

### Common Issues

1. **Port already in use**:
   ```bash
   sudo lsof -i :3000
   sudo kill -9 <PID>
   ```

2. **Permission denied**:
   ```bash
   sudo chown -R $USER:$USER /path/to/app
   ```

3. **Memory issues**:
   - Increase server memory
   - Optimize code
   - Use PM2 memory restart

### Getting Help

- Check application logs: `pm2 logs`
- Check system logs: `sudo journalctl -u nginx`
- Monitor resources: `htop` or `top`

## Performance Optimization

1. **Enable Gzip compression** in Nginx
2. **Set up CDN** for static assets
3. **Implement caching** strategies
4. **Database optimization** when migrating from in-memory storage

Your Student Attendance System is now ready for production deployment!