import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  GraduationCap, 
  BarChart3, 
  Users, 
  CalendarCheck, 
  Book, 
  ChartBar, 
  Settings 
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigation = [
  { name: "Dashboard", href: "/", icon: BarChart3 },
  { name: "Students", href: "/students", icon: Users },
  { name: "Attendance", href: "/attendance", icon: CalendarCheck },
  { name: "Classes", href: "/classes", icon: Book },
  { name: "Reports", href: "/reports", icon: ChartBar },
  { name: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-0 h-full w-64 bg-white border-r border-border shadow-lg transform transition-transform duration-300 z-40",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <div className="p-6">
          <div className="flex items-center mb-8">
            <GraduationCap className="text-primary text-2xl mr-3" size={32} />
            <h1 className="text-xl font-bold text-text-primary">ClassTrack</h1>
          </div>
          
          <nav className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              
              return (
                <Link key={item.name} href={item.href}>
                  <a className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-colors",
                    isActive 
                      ? "sidebar-active" 
                      : "text-text-secondary hover:bg-gray-50 hover:text-text-primary"
                  )}>
                    <Icon className="mr-3" size={20} />
                    {item.name}
                  </a>
                </Link>
              );
            })}
          </nav>
        </div>
        
        {/* User Profile Section */}
        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-border">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-semibold">
              MS
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-text-primary">Ms. Sarah Johnson</p>
              <p className="text-xs text-text-secondary">Mathematics Teacher</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
