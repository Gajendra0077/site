import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { getInitials, getTodayDate, getCurrentTime } from "@/lib/utils";
import { Check, Clock, X, FileText } from "lucide-react";
import type { StudentWithAttendance, Class } from "@shared/schema";

interface AttendanceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface AttendanceRecord {
  studentId: number;
  status: "present" | "absent" | "late" | "excused";
  time?: string;
}

export default function AttendanceModal({ open, onOpenChange }: AttendanceModalProps) {
  const [selectedClassId, setSelectedClassId] = useState<string>("");
  const [attendanceRecords, setAttendanceRecords] = useState<Record<number, AttendanceRecord>>({});
  const { toast } = useToast();

  const { data: classes, isLoading: classesLoading } = useQuery({
    queryKey: ["/api/classes"],
    enabled: open,
  });

  const { data: students, isLoading: studentsLoading } = useQuery({
    queryKey: ["/api/students/with-attendance"],
    enabled: open,
  });

  const saveAttendanceMutation = useMutation({
    mutationFn: async (attendanceData: AttendanceRecord[]) => {
      const payload = attendanceData.map(record => ({
        studentId: record.studentId,
        classId: parseInt(selectedClassId),
        date: getTodayDate(),
        status: record.status,
        time: record.time || getCurrentTime(),
        notes: ""
      }));
      
      return apiRequest("POST", "/api/attendance/bulk", payload);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Attendance saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/students/with-attendance"] });
      onOpenChange(false);
      setAttendanceRecords({});
      setSelectedClassId("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save attendance",
        variant: "destructive",
      });
    },
  });

  // Reset state when modal closes
  useEffect(() => {
    if (!open) {
      setAttendanceRecords({});
      setSelectedClassId("");
    }
  }, [open]);

  const handleStatusChange = (studentId: number, status: "present" | "absent" | "late" | "excused") => {
    setAttendanceRecords(prev => ({
      ...prev,
      [studentId]: {
        studentId,
        status,
        time: status === "present" || status === "late" ? getCurrentTime() : undefined
      }
    }));
  };

  const handleSave = () => {
    if (!selectedClassId) {
      toast({
        title: "Error", 
        description: "Please select a class",
        variant: "destructive",
      });
      return;
    }

    const recordsToSave = Object.values(attendanceRecords);
    if (recordsToSave.length === 0) {
      toast({
        title: "Error",
        description: "Please mark attendance for at least one student",
        variant: "destructive",
      });
      return;
    }

    saveAttendanceMutation.mutate(recordsToSave);
  };

  const getStatusButton = (studentId: number, status: "present" | "absent" | "late" | "excused", label: string, icon: React.ReactNode) => {
    const currentStatus = attendanceRecords[studentId]?.status;
    const isActive = currentStatus === status;
    
    const baseClasses = "px-3 py-1 rounded-lg text-sm font-medium flex items-center transition-colors";
    const activeClasses = {
      present: "bg-green-500 text-white",
      late: "bg-orange-500 text-white", 
      absent: "bg-red-500 text-white",
      excused: "bg-purple-500 text-white"
    };
    const inactiveClasses = "bg-gray-200 text-text-primary hover:bg-gray-300";
    
    return (
      <Button
        type="button"
        size="sm"
        onClick={() => handleStatusChange(studentId, status)}
        className={`${baseClasses} ${isActive ? activeClasses[status] : inactiveClasses}`}
        variant="ghost"
      >
        <span className="mr-1">{icon}</span>
        {label}
      </Button>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-text-primary">Take Attendance</DialogTitle>
          <p className="text-text-secondary mt-2">Select class and mark attendance for students</p>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">Select Class</label>
            {classesLoading ? (
              <Skeleton className="h-10 w-full" />
            ) : (
              <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Choose a class" />
                </SelectTrigger>
                <SelectContent>
                  {classes?.map((cls: Class) => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>
                      {cls.name} - {cls.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          
          <div className="space-y-4">
            {studentsLoading ? (
              [...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div className="ml-4">
                      <Skeleton className="h-4 w-32 mb-2" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {[...Array(4)].map((_, j) => (
                      <Skeleton key={j} className="h-8 w-20" />
                    ))}
                  </div>
                </div>
              ))
            ) : students?.length === 0 ? (
              <div className="text-center text-text-secondary py-8">
                No students found
              </div>
            ) : (
              students?.map((student: StudentWithAttendance) => (
                <div key={student.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-text-primary font-semibold">
                      {getInitials(student.firstName, student.lastName)}
                    </div>
                    <div className="ml-4">
                      <p className="font-medium text-text-primary">
                        {student.firstName} {student.lastName}
                      </p>
                      <p className="text-sm text-text-secondary">#{student.studentId}</p>
                      {student.todayAttendance && (
                        <Badge variant="outline" className="text-xs mt-1">
                          Already marked: {student.todayAttendance.status}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusButton(student.id, "present", "Present", <Check size={14} />)}
                    {getStatusButton(student.id, "late", "Late", <Clock size={14} />)}
                    {getStatusButton(student.id, "absent", "Absent", <X size={14} />)}
                    {getStatusButton(student.id, "excused", "Excused", <FileText size={14} />)}
                  </div>
                </div>
              ))
            )}
          </div>
          
          <div className="flex items-center justify-end space-x-4 pt-4 border-t border-border">
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={saveAttendanceMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={saveAttendanceMutation.isPending}
              className="bg-primary text-white hover:bg-blue-700"
            >
              {saveAttendanceMutation.isPending ? "Saving..." : "Save Attendance"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
