import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Clock, Info } from "lucide-react";

export default function RecentAlerts() {
  // In a real app, this would come from an API or state management
  const alerts = [
    {
      id: 1,
      type: "warning",
      icon: AlertTriangle,
      title: "High Absenteeism",
      message: "Sarah Wilson has been absent for 3 consecutive days",
      time: "2 hours ago",
      className: "bg-red-50 border-l-4 border-red-500",
      iconColor: "text-red-500"
    },
    {
      id: 2,
      type: "info",
      icon: Clock,
      title: "Frequent Tardiness",
      message: "James Davis has been late 4 times this week",
      time: "1 day ago",
      className: "bg-orange-50 border-l-4 border-orange-500",
      iconColor: "text-orange-500"
    },
    {
      id: 3,
      type: "info",
      icon: Info,
      title: "Attendance Report Ready",
      message: "Weekly attendance report is ready for download",
      time: "2 days ago",
      className: "bg-blue-50 border-l-4 border-blue-500",
      iconColor: "text-blue-500"
    }
  ];

  return (
    <Card className="bg-white shadow-sm border border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-text-primary">Recent Alerts</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.length === 0 ? (
          <div className="text-center text-text-secondary py-4">
            No recent alerts
          </div>
        ) : (
          alerts.map((alert) => {
            const Icon = alert.icon;
            return (
              <div key={alert.id} className={`flex items-start p-3 rounded-lg ${alert.className}`}>
                <Icon className={`${alert.iconColor} mt-1 mr-3 flex-shrink-0`} size={20} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-text-primary">{alert.title}</p>
                  <p className="text-xs text-text-secondary mt-1 line-clamp-2">{alert.message}</p>
                  <p className="text-xs text-text-secondary mt-1">{alert.time}</p>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
