import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, CheckCircle, XCircle, Clock, TrendingUp, TrendingDown } from "lucide-react";

interface StatsData {
  totalStudents: number;
  presentToday: number;
  absentToday: number;
  lateToday: number;
  attendanceRate: number;
}

interface StatsCardsProps {
  data?: StatsData;
  isLoading: boolean;
}

export default function StatsCards({ data, isLoading }: StatsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-white shadow-sm border border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="w-12 h-12 rounded-lg" />
              </div>
              <div className="mt-4">
                <Skeleton className="h-4 w-20" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-white shadow-sm border border-border">
          <CardContent className="p-6">
            <div className="text-center text-text-secondary">
              No statistics available
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const cards = [
    {
      title: "Total Students",
      value: data.totalStudents,
      icon: Users,
      iconBg: "bg-blue-100",
      iconColor: "text-primary",
      trend: "+3",
      trendText: "from last week",
      trendIcon: TrendingUp,
      trendColor: "text-green-600"
    },
    {
      title: "Present Today",
      value: data.presentToday,
      icon: CheckCircle,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: `${data.attendanceRate}%`,
      trendText: "attendance rate",
      trendColor: "text-green-600"
    },
    {
      title: "Absent Today",
      value: data.absentToday,
      icon: XCircle,
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      trend: "-2",
      trendText: "from yesterday",
      trendIcon: TrendingDown,
      trendColor: "text-red-600"
    },
    {
      title: "Late Arrivals",
      value: data.lateToday,
      icon: Clock,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      trend: "2.4/day",
      trendText: "average",
      trendColor: "text-orange-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => {
        const Icon = card.icon;
        const TrendIcon = card.trendIcon;
        
        return (
          <Card key={index} className="bg-white shadow-sm border border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-secondary text-sm font-medium">{card.title}</p>
                  <p className="text-3xl font-bold text-text-primary mt-2">{card.value}</p>
                </div>
                <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${card.iconColor} text-xl`} size={24} />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                {TrendIcon && <TrendIcon className={`${card.trendColor} mr-1`} size={16} />}
                <span className={`${card.trendColor} font-medium`}>{card.trend}</span>
                <span className="text-text-secondary ml-1">{card.trendText}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
