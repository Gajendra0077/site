import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function ClassSchedule() {
  const { data: classes, isLoading } = useQuery({
    queryKey: ["/api/classes"],
  });

  // Mock today's schedule - in a real app, this would be calculated based on current day and time
  const todaySchedule = [
    {
      id: 1,
      name: "Mathematics 101",
      time: "8:00 AM - 9:30 AM",
      status: "complete"
    },
    {
      id: 2,
      name: "Science 102", 
      time: "10:00 AM - 11:30 AM",
      status: "current"
    },
    {
      id: 3,
      name: "History 103",
      time: "1:00 PM - 2:30 PM", 
      status: "upcoming"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "complete":
        return <Badge className="bg-green-500 text-white text-xs">✓ Complete</Badge>;
      case "current":
        return <Badge className="bg-primary text-white text-xs">Current</Badge>;
      case "upcoming":
        return <Badge variant="secondary" className="text-xs">Upcoming</Badge>;
      default:
        return <Badge variant="secondary" className="text-xs">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-white shadow-sm border border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-text-primary">Today's Schedule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <Skeleton className="h-4 w-32 mb-2" />
                <Skeleton className="h-3 w-24" />
              </div>
              <Skeleton className="h-6 w-16" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white shadow-sm border border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-text-primary">Today's Schedule</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {todaySchedule.length === 0 ? (
          <div className="text-center text-text-secondary py-4">
            No classes scheduled for today
          </div>
        ) : (
          todaySchedule.map((classItem) => (
            <div 
              key={classItem.id} 
              className={`flex items-center justify-between p-3 rounded-lg ${
                classItem.status === "current" 
                  ? "bg-blue-50 border-l-4 border-primary" 
                  : "bg-gray-50"
              }`}
            >
              <div>
                <p className="font-medium text-text-primary">{classItem.name}</p>
                <p className="text-sm text-text-secondary">{classItem.time}</p>
              </div>
              {getStatusBadge(classItem.status)}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
