import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ClipboardCheck, UserPlus, Download, TrendingUp } from "lucide-react";

interface QuickActionsProps {
  onTakeAttendance: () => void;
}

export default function QuickActions({ onTakeAttendance }: QuickActionsProps) {
  const actions = [
    {
      label: "Take Attendance",
      icon: ClipboardCheck,
      onClick: onTakeAttendance,
      className: "bg-blue-50 text-primary hover:bg-blue-100"
    },
    {
      label: "Add New Student",
      icon: UserPlus,
      onClick: () => {
        // Navigate to add student page or open modal
        console.log("Add new student");
      },
      className: "bg-gray-50 text-text-primary hover:bg-gray-100"
    },
    {
      label: "Generate Report",
      icon: Download,
      onClick: () => {
        // Generate and download report
        console.log("Generate report");
      },
      className: "bg-gray-50 text-text-primary hover:bg-gray-100"
    },
    {
      label: "View Analytics",
      icon: TrendingUp,
      onClick: () => {
        // Navigate to analytics page
        console.log("View analytics");
      },
      className: "bg-gray-50 text-text-primary hover:bg-gray-100"
    }
  ];

  return (
    <Card className="bg-white shadow-sm border border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-text-primary">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <Button
              key={index}
              onClick={action.onClick}
              className={`w-full justify-start ${action.className}`}
              variant="ghost"
            >
              <Icon className="mr-3" size={20} />
              {action.label}
            </Button>
          );
        })}
      </CardContent>
    </Card>
  );
}
