import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit, MoreVertical, ChevronLeft, ChevronRight } from "lucide-react";
import { cn, getInitials, formatTime, getAttendanceStatusIcon } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import type { AttendanceWithStudent } from "@shared/schema";

interface AttendanceTableProps {
  data?: AttendanceWithStudent[];
  isLoading: boolean;
}

export default function AttendanceTable({ data, isLoading }: AttendanceTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const { data: classes } = useQuery({
    queryKey: ["/api/classes"],
  });

  if (isLoading) {
    return (
      <Card className="bg-white shadow-sm border border-border">
        <CardHeader className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <Skeleton className="h-6 w-40" />
            <div className="flex items-center space-x-3">
              <Skeleton className="h-10 w-64" />
              <Skeleton className="h-10 w-32" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="space-y-4 p-6">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <Skeleton className="h-6 w-20" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-8" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data || data.length === 0) {
    return (
      <Card className="bg-white shadow-sm border border-border">
        <CardHeader className="p-6 border-b border-border">
          <h3 className="text-lg font-semibold text-text-primary">Today's Attendance</h3>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center text-text-secondary">
            No attendance records found for today
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filter data
  const filteredData = data.filter(record => {
    const matchesSearch = 
      record.student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.student.studentId.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesClass = selectedClass === "all" || record.classId.toString() === selectedClass;
    
    return matchesSearch && matchesClass;
  });

  // Pagination
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedData = filteredData.slice(startIndex, startIndex + itemsPerPage);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      present: { label: "Present", className: "status-present", icon: "check-circle" },
      absent: { label: "Absent", className: "status-absent", icon: "x-circle" },
      late: { label: "Late", className: "status-late", icon: "clock" },
      excused: { label: "Excused", className: "status-excused", icon: "file-text" }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      label: status,
      className: "bg-gray-100 text-gray-800",
      icon: "help-circle"
    };

    return (
      <Badge className={cn("inline-flex items-center", config.className)}>
        <span className="mr-1">
          {config.icon === "check-circle" && "✓"}
          {config.icon === "x-circle" && "✗"}
          {config.icon === "clock" && "⏰"}
          {config.icon === "file-text" && "📄"}
        </span>
        {config.label}
      </Badge>
    );
  };

  return (
    <Card className="bg-white shadow-sm border border-border">
      <CardHeader className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-text-primary">Today's Attendance</h3>
          <div className="flex items-center space-x-3">
            {/* Search */}
            <div className="relative">
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-64"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" size={16} />
            </div>
            
            {/* Filter */}
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Classes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes?.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id.toString()}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-4 font-medium text-text-secondary text-sm">Student</th>
                <th className="text-left px-6 py-4 font-medium text-text-secondary text-sm">Class</th>
                <th className="text-left px-6 py-4 font-medium text-text-secondary text-sm">Status</th>
                <th className="text-left px-6 py-4 font-medium text-text-secondary text-sm">Time</th>
                <th className="text-right px-6 py-4 font-medium text-text-secondary text-sm">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginatedData.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-text-primary font-semibold">
                        {getInitials(record.student.firstName, record.student.lastName)}
                      </div>
                      <div className="ml-4">
                        <p className="font-medium text-text-primary">
                          {record.student.firstName} {record.student.lastName}
                        </p>
                        <p className="text-sm text-text-secondary">#{record.student.studentId}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-text-primary">{record.class.name}</span>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(record.status)}
                  </td>
                  <td className="px-6 py-4 text-text-secondary">
                    {formatTime(record.time || "")}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="ghost" size="sm">
                        <Edit className="text-primary" size={16} />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="text-text-secondary" size={16} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="px-6 py-4 border-t border-border">
          <div className="flex items-center justify-between">
            <p className="text-sm text-text-secondary">
              Showing {startIndex + 1} to {Math.min(startIndex + itemsPerPage, filteredData.length)} of {filteredData.length} students
            </p>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft size={16} />
                Previous
              </Button>
              
              {[...Array(totalPages)].map((_, i) => (
                <Button
                  key={i + 1}
                  variant={currentPage === i + 1 ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(i + 1)}
                  className="w-8 h-8 p-0"
                >
                  {i + 1}
                </Button>
              ))}
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Next
                <ChevronRight size={16} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
