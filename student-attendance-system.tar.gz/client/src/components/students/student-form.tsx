import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { insertStudentSchema } from "@shared/schema";
import type { Student, InsertStudent } from "@shared/schema";
import { z } from "zod";

const formSchema = insertStudentSchema.extend({
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  parentPhone: z.string().min(1, "Parent phone is required"),
});

type FormData = z.infer<typeof formSchema>;

interface StudentFormProps {
  student: Student | null;
  onClose: () => void;
}

export default function StudentForm({ student, onClose }: StudentFormProps) {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      studentId: "",
      email: "",
      parentPhone: "",
      grade: "",
      active: true,
    },
  });

  // Populate form when editing
  useEffect(() => {
    if (student) {
      form.reset({
        firstName: student.firstName,
        lastName: student.lastName,
        studentId: student.studentId,
        email: student.email || "",
        parentPhone: student.parentPhone || "",
        grade: student.grade || "",
        active: student.active,
      });
    }
  }, [student, form]);

  const createStudentMutation = useMutation({
    mutationFn: async (data: InsertStudent) => {
      return apiRequest("POST", "/api/students", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Student created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create student",
        variant: "destructive",
      });
    },
  });

  const updateStudentMutation = useMutation({
    mutationFn: async (data: Partial<InsertStudent>) => {
      return apiRequest("PUT", `/api/students/${student!.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Student updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update student",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    // Convert empty email to undefined
    const submitData: InsertStudent = {
      ...data,
      email: data.email || undefined,
      parentPhone: data.parentPhone,
      grade: data.grade || undefined,
    };

    if (student) {
      updateStudentMutation.mutate(submitData);
    } else {
      createStudentMutation.mutate(submitData);
    }
  };

  const isLoading = createStudentMutation.isPending || updateStudentMutation.isPending;

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">First Name *</Label>
          <Input
            id="firstName"
            {...form.register("firstName")}
            placeholder="Enter first name"
            className="mt-1"
          />
          {form.formState.errors.firstName && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.firstName.message}
            </p>
          )}
        </div>
        
        <div>
          <Label htmlFor="lastName">Last Name *</Label>
          <Input
            id="lastName"
            {...form.register("lastName")}
            placeholder="Enter last name"
            className="mt-1"
          />
          {form.formState.errors.lastName && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.lastName.message}
            </p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="studentId">Student ID *</Label>
        <Input
          id="studentId"
          {...form.register("studentId")}
          placeholder="Enter student ID"
          className="mt-1"
        />
        {form.formState.errors.studentId && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.studentId.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          {...form.register("email")}
          placeholder="Enter email address"
          className="mt-1"
        />
        {form.formState.errors.email && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.email.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="parentPhone">Parent WhatsApp Number *</Label>
        <Input
          id="parentPhone"
          type="tel"
          {...form.register("parentPhone")}
          placeholder="Enter parent's WhatsApp number (e.g., +1234567890)"
          className="mt-1"
        />
        {form.formState.errors.parentPhone && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.parentPhone.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="grade">Grade</Label>
        <Input
          id="grade"
          {...form.register("grade")}
          placeholder="Enter grade level"
          className="mt-1"
        />
        {form.formState.errors.grade && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.grade.message}
          </p>
        )}
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="bg-primary text-white hover:bg-blue-700">
          {isLoading ? "Saving..." : student ? "Update Student" : "Create Student"}
        </Button>
      </div>
    </form>
  );
}
