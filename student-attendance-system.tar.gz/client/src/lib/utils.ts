import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function formatTime(time: string): string {
  if (!time) return '—';
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
}

export function getInitials(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
}

export function getAttendanceStatusColor(status: string): string {
  switch (status) {
    case 'present':
      return 'status-present';
    case 'absent':
      return 'status-absent';
    case 'late':
      return 'status-late';
    case 'excused':
      return 'status-excused';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

export function getAttendanceStatusIcon(status: string): string {
  switch (status) {
    case 'present':
      return 'check-circle';
    case 'absent':
      return 'x-circle';
    case 'late':
      return 'clock';
    case 'excused':
      return 'file-text';
    default:
      return 'help-circle';
  }
}

export function getTodayDate(): string {
  return new Date().toISOString().split('T')[0];
}

export function getCurrentTime(): string {
  const now = new Date();
  return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
}
