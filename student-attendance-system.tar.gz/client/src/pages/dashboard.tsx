import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import StatsCards from "@/components/dashboard/stats-cards";
import AttendanceTable from "@/components/dashboard/attendance-table";
import QuickActions from "@/components/dashboard/quick-actions";
import RecentAlerts from "@/components/dashboard/recent-alerts";
import ClassSchedule from "@/components/dashboard/class-schedule";
import AttendanceModal from "@/components/attendance/attendance-modal";
import { Button } from "@/components/ui/button";
import { Bell, Menu, Plus } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [attendanceModalOpen, setAttendanceModalOpen] = useState(false);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/attendance/stats"],
  });

  const { data: todayAttendance, isLoading: attendanceLoading } = useQuery({
    queryKey: ["/api/attendance/today"],
  });

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--surface)'}}>
      {/* Mobile Navigation Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setSidebarOpen(true)}
          className="bg-white shadow-lg"
        >
          <Menu size={20} />
        </Button>
      </div>

      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content Area */}
      <main className="lg:ml-64 min-h-screen">
        {/* Top Bar */}
        <header className="bg-white border-b border-border p-4 lg:p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-text-primary">Dashboard</h2>
              <p className="text-text-secondary mt-1">{formatDate(new Date())}</p>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Quick Actions */}
              <Button 
                onClick={() => setAttendanceModalOpen(true)}
                className="bg-primary text-white hover:bg-blue-700"
              >
                <Plus className="mr-2" size={16} />
                Take Attendance
              </Button>
              
              {/* Notifications */}
              <div className="relative">
                <Button variant="ghost" size="sm">
                  <Bell size={20} />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full"></span>
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="p-4 lg:p-6">
          {/* Statistics Cards */}
          <StatsCards data={stats} isLoading={statsLoading} />

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Attendance Table */}
            <div className="xl:col-span-2">
              <AttendanceTable 
                data={todayAttendance} 
                isLoading={attendanceLoading} 
              />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              <QuickActions onTakeAttendance={() => setAttendanceModalOpen(true)} />
              <RecentAlerts />
              <ClassSchedule />
            </div>
          </div>
        </div>
      </main>

      {/* Floating Action Button for Mobile */}
      <Button
        className="lg:hidden fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg z-30"
        onClick={() => setAttendanceModalOpen(true)}
      >
        <Plus size={24} />
      </Button>

      {/* Attendance Modal */}
      <AttendanceModal 
        open={attendanceModalOpen} 
        onOpenChange={setAttendanceModalOpen}
      />
    </div>
  );
}
