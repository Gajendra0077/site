import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

export default function Attendance() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--surface)'}}>
      {/* Mobile Navigation Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setSidebarOpen(true)}
          className="bg-white shadow-lg"
        >
          <Menu size={20} />
        </Button>
      </div>

      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content Area */}
      <main className="lg:ml-64 min-h-screen">
        {/* Top Bar */}
        <header className="bg-white border-b border-border p-4 lg:p-6">
          <div>
            <h2 className="text-2xl font-bold text-text-primary">Attendance Management</h2>
            <p className="text-text-secondary mt-1">View and manage attendance records</p>
          </div>
        </header>

        <div className="p-4 lg:p-6">
          <div className="bg-white rounded-xl shadow-sm border border-border p-8 text-center">
            <h3 className="text-lg font-semibold text-text-primary mb-2">Attendance Management</h3>
            <p className="text-text-secondary">
              This page will contain detailed attendance management features including
              historical records, filtering, and reporting capabilities.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
