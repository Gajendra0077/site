import twilio from 'twilio';

interface NotificationService {
  sendWhatsAppMessage(to: string, message: string): Promise<boolean>;
  sendAttendanceAlert(studentName: string, parentPhone: string, status: 'absent' | 'late', className: string): Promise<boolean>;
}

class TwilioNotificationService implements NotificationService {
  private client: any;
  private fromNumber: string;

  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    this.fromNumber = process.env.TWILIO_PHONE_NUMBER || '';

    if (accountSid && authToken) {
      this.client = twilio(accountSid, authToken);
    }
  }

  async sendWhatsAppMessage(to: string, message: string): Promise<boolean> {
    if (!this.client) {
      console.log('Twilio not configured - message would be sent:', { to, message });
      return false;
    }

    try {
      await this.client.messages.create({
        body: message,
        from: `whatsapp:${this.fromNumber}`,
        to: `whatsapp:${to}`
      });
      return true;
    } catch (error) {
      console.error('Failed to send WhatsApp message:', error);
      return false;
    }
  }

  async sendAttendanceAlert(studentName: string, parentPhone: string, status: 'absent' | 'late', className: string): Promise<boolean> {
    const statusMessages = {
      absent: `🚨 Attendance Alert: Your child ${studentName} is marked ABSENT from ${className} class today. Please contact the school if this is incorrect.`,
      late: `⏰ Attendance Alert: Your child ${studentName} arrived LATE to ${className} class today.`
    };

    const message = statusMessages[status];
    return this.sendWhatsAppMessage(parentPhone, message);
  }
}

// Mock service for when Twilio is not configured
class MockNotificationService implements NotificationService {
  async sendWhatsAppMessage(to: string, message: string): Promise<boolean> {
    console.log(`Mock WhatsApp message to ${to}: ${message}`);
    return true;
  }

  async sendAttendanceAlert(studentName: string, parentPhone: string, status: 'absent' | 'late', className: string): Promise<boolean> {
    console.log(`Mock attendance alert for ${studentName} (${status}) to ${parentPhone} for class ${className}`);
    return true;
  }
}

export const notificationService: NotificationService = process.env.TWILIO_ACCOUNT_SID 
  ? new TwilioNotificationService() 
  : new MockNotificationService();