import { 
  students, 
  classes, 
  attendance, 
  type Student, 
  type InsertStudent,
  type Class,
  type InsertClass,
  type Attendance,
  type InsertAttendance,
  type AttendanceWithStudent,
  type StudentWithAttendance
} from "@shared/schema";

export interface IStorage {
  // Students
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  getAllStudents(): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;

  // Classes
  getClass(id: number): Promise<Class | undefined>;
  getClassByCode(code: string): Promise<Class | undefined>;
  getAllClasses(): Promise<Class[]>;
  createClass(classData: InsertClass): Promise<Class>;
  updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined>;
  deleteClass(id: number): Promise<boolean>;

  // Attendance
  getAttendance(id: number): Promise<Attendance | undefined>;
  getAttendanceByDateAndClass(date: string, classId: number): Promise<AttendanceWithStudent[]>;
  getAttendanceByStudent(studentId: number, startDate?: string, endDate?: string): Promise<Attendance[]>;
  getTodayAttendance(): Promise<AttendanceWithStudent[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<boolean>;

  // Dashboard stats
  getAttendanceStats(date?: string): Promise<{
    totalStudents: number;
    presentToday: number;
    absentToday: number;
    lateToday: number;
    attendanceRate: number;
  }>;

  // Get students with today's attendance
  getStudentsWithTodayAttendance(): Promise<StudentWithAttendance[]>;
}

export class MemStorage implements IStorage {
  private students: Map<number, Student>;
  private classes: Map<number, Class>;
  private attendance: Map<number, Attendance>;
  private currentStudentId: number;
  private currentClassId: number;
  private currentAttendanceId: number;

  constructor() {
    this.students = new Map();
    this.classes = new Map();
    this.attendance = new Map();
    this.currentStudentId = 1;
    this.currentClassId = 1;
    this.currentAttendanceId = 1;

    // Initialize with some default classes
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default classes
    const defaultClasses = [
      { name: "Mathematics 101", code: "MATH101", description: "Introduction to Mathematics", schedule: '{"time": "8:00 AM - 9:30 AM", "days": ["Mon", "Wed", "Fri"]}', active: true },
      { name: "Science 102", code: "SCI102", description: "General Science", schedule: '{"time": "10:00 AM - 11:30 AM", "days": ["Tue", "Thu"]}', active: true },
      { name: "History 103", code: "HIST103", description: "World History", schedule: '{"time": "1:00 PM - 2:30 PM", "days": ["Mon", "Wed", "Fri"]}', active: true },
    ];

    defaultClasses.forEach(classData => {
      const id = this.currentClassId++;
      const newClass: Class = { ...classData, id };
      this.classes.set(id, newClass);
    });
  }

  // Students
  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(student => student.studentId === studentId);
  }

  async getAllStudents(): Promise<Student[]> {
    return Array.from(this.students.values()).filter(student => student.active);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.currentStudentId++;
    const student: Student = { 
      ...insertStudent, 
      id,
      email: insertStudent.email || null,
      parentPhone: insertStudent.parentPhone || null,
      grade: insertStudent.grade || null,
      active: insertStudent.active ?? true
    };
    this.students.set(id, student);
    return student;
  }

  async updateStudent(id: number, studentData: Partial<InsertStudent>): Promise<Student | undefined> {
    const student = this.students.get(id);
    if (!student) return undefined;
    
    const updatedStudent = { ...student, ...studentData };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    const student = this.students.get(id);
    if (!student) return false;
    
    // Soft delete
    const updatedStudent = { ...student, active: false };
    this.students.set(id, updatedStudent);
    return true;
  }

  // Classes
  async getClass(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }

  async getClassByCode(code: string): Promise<Class | undefined> {
    return Array.from(this.classes.values()).find(cls => cls.code === code);
  }

  async getAllClasses(): Promise<Class[]> {
    return Array.from(this.classes.values()).filter(cls => cls.active);
  }

  async createClass(insertClass: InsertClass): Promise<Class> {
    const id = this.currentClassId++;
    const classData: Class = { 
      ...insertClass, 
      id,
      description: insertClass.description || null,
      schedule: insertClass.schedule || null,
      active: insertClass.active ?? true
    };
    this.classes.set(id, classData);
    return classData;
  }

  async updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined> {
    const existingClass = this.classes.get(id);
    if (!existingClass) return undefined;
    
    const updatedClass = { ...existingClass, ...classData };
    this.classes.set(id, updatedClass);
    return updatedClass;
  }

  async deleteClass(id: number): Promise<boolean> {
    const classData = this.classes.get(id);
    if (!classData) return false;
    
    // Soft delete
    const updatedClass = { ...classData, active: false };
    this.classes.set(id, updatedClass);
    return true;
  }

  // Attendance
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendance.get(id);
  }

  async getAttendanceByDateAndClass(date: string, classId: number): Promise<AttendanceWithStudent[]> {
    const attendanceRecords = Array.from(this.attendance.values())
      .filter(att => att.date === date && att.classId === classId);
    
    const result: AttendanceWithStudent[] = [];
    for (const att of attendanceRecords) {
      const student = this.students.get(att.studentId);
      const classData = this.classes.get(att.classId);
      if (student && classData) {
        result.push({ ...att, student, class: classData });
      }
    }
    return result;
  }

  async getAttendanceByStudent(studentId: number, startDate?: string, endDate?: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(att => {
      if (att.studentId !== studentId) return false;
      if (startDate && att.date < startDate) return false;
      if (endDate && att.date > endDate) return false;
      return true;
    });
  }

  async getTodayAttendance(): Promise<AttendanceWithStudent[]> {
    const today = new Date().toISOString().split('T')[0];
    const attendanceRecords = Array.from(this.attendance.values())
      .filter(att => att.date === today);
    
    const result: AttendanceWithStudent[] = [];
    for (const att of attendanceRecords) {
      const student = this.students.get(att.studentId);
      const classData = this.classes.get(att.classId);
      if (student && classData) {
        result.push({ ...att, student, class: classData });
      }
    }
    return result;
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.currentAttendanceId++;
    const attendance: Attendance = { 
      ...insertAttendance, 
      id,
      time: insertAttendance.time || null,
      notes: insertAttendance.notes || null
    };
    this.attendance.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const attendance = this.attendance.get(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { ...attendance, ...attendanceData };
    this.attendance.set(id, updatedAttendance);
    return updatedAttendance;
  }

  async deleteAttendance(id: number): Promise<boolean> {
    return this.attendance.delete(id);
  }

  async getAttendanceStats(date?: string): Promise<{
    totalStudents: number;
    presentToday: number;
    absentToday: number;
    lateToday: number;
    attendanceRate: number;
  }> {
    const targetDate = date || new Date().toISOString().split('T')[0];
    const totalStudents = Array.from(this.students.values()).filter(s => s.active).length;
    
    const todayAttendance = Array.from(this.attendance.values())
      .filter(att => att.date === targetDate);
    
    const presentToday = todayAttendance.filter(att => att.status === 'present').length;
    const absentToday = todayAttendance.filter(att => att.status === 'absent').length;
    const lateToday = todayAttendance.filter(att => att.status === 'late').length;
    const attendanceRate = totalStudents > 0 ? Math.round((presentToday / totalStudents) * 100 * 10) / 10 : 0;

    return {
      totalStudents,
      presentToday,
      absentToday,
      lateToday,
      attendanceRate
    };
  }

  async getStudentsWithTodayAttendance(): Promise<StudentWithAttendance[]> {
    const today = new Date().toISOString().split('T')[0];
    const activeStudents = Array.from(this.students.values()).filter(s => s.active);
    
    return activeStudents.map(student => {
      const todayAttendance = Array.from(this.attendance.values())
        .find(att => att.studentId === student.id && att.date === today);
      
      return {
        ...student,
        todayAttendance
      };
    });
  }
}

export const storage = new MemStorage();
